# FREE FIRE HEADSHOT PANEL

A simple standalone Kivy settings-demo app. It saves its own local demo settings.

**Important:** This app does not interact with, modify, inject into, or cheat in Free Fire. The headshot and aim-assist switches are demo-only; the DPI slider is display-only.

## Build the APK with GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run, scroll to **Artifacts**, and download `free-fire-headshot-panel-apk`.
6. Extract the ZIP and install the APK on your Android phone. Android may ask you to allow installs from your browser/files app.

This workflow creates a debug APK for arm64 Android devices.
