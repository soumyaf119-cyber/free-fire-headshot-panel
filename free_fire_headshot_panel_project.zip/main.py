import json
from pathlib import Path

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.slider import Slider
from kivy.uix.switch import Switch
from kivy.uix.button import Button
from kivy.uix.popup import Popup

SETTINGS_FILE = Path("settings.json")

class PanelApp(App):
    def build(self):
        self.title = "FREE FIRE HEADSHOT PANEL"
        self.settings = {
            "headshot_profile": False,
            "sensitivity": 100,
            "dpi": 400,
            "aim_assist_demo": False,
        }
        self.load_settings()

        root = BoxLayout(orientation="vertical", padding=dp(18), spacing=dp(12))
        root.add_widget(Label(
            text="[b]🔥 FREE FIRE HEADSHOT PANEL 🔥[/b]\n[color=ffcc00]SETTINGS DEMO[/color]",
            markup=True, font_size="21sp", size_hint_y=None, height=dp(85)
        ))

        self.head_switch = Switch(active=self.settings["headshot_profile"])
        root.add_widget(self.row("Headshot Profile (demo)", self.head_switch))

        self.sens_label = Label(text=f"Sensitivity: {self.settings['sensitivity']}", size_hint_y=None, height=dp(30))
        root.add_widget(self.sens_label)
        self.sens_slider = Slider(min=1, max=200, value=self.settings["sensitivity"])
        self.sens_slider.bind(value=self.update_sensitivity)
        root.add_widget(self.sens_slider)

        self.dpi_label = Label(text=f"DPI (display only): {self.settings['dpi']}", size_hint_y=None, height=dp(30))
        root.add_widget(self.dpi_label)
        self.dpi_slider = Slider(min=100, max=1000, value=self.settings["dpi"])
        self.dpi_slider.bind(value=self.update_dpi)
        root.add_widget(self.dpi_slider)

        self.aim_switch = Switch(active=self.settings["aim_assist_demo"])
        root.add_widget(self.row("Aim Assist (demo only)", self.aim_switch))

        save_btn = Button(text="SAVE SETTINGS", size_hint_y=None, height=dp(52))
        save_btn.bind(on_press=self.save_settings)
        root.add_widget(save_btn)

        note = Label(
            text="This is an independent settings demo. It does not modify Free Fire, "
                 "provide aimbot/headshot cheats, or change in-game sensitivity.",
            font_size="12sp", halign="center", valign="middle",
            size_hint_y=None, height=dp(65)
        )
        note.bind(size=lambda inst, val: setattr(inst, "text_size", val))
        root.add_widget(note)
        return root

    def row(self, title, control):
        box = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
        box.add_widget(Label(text=title, halign="left"))
        box.add_widget(control)
        return box

    def update_sensitivity(self, _, value):
        self.sens_label.text = f"Sensitivity: {int(value)}"

    def update_dpi(self, _, value):
        self.dpi_label.text = f"DPI (display only): {int(value)}"

    def load_settings(self):
        try:
            if SETTINGS_FILE.exists():
                loaded = json.loads(SETTINGS_FILE.read_text())
                self.settings.update(loaded)
        except Exception:
            pass

    def save_settings(self, _):
        self.settings = {
            "headshot_profile": self.head_switch.active,
            "sensitivity": int(self.sens_slider.value),
            "dpi": int(self.dpi_slider.value),
            "aim_assist_demo": self.aim_switch.active,
        }
        SETTINGS_FILE.write_text(json.dumps(self.settings, indent=2))
        Popup(
            title="Saved",
            content=Label(text="Your demo settings were saved on this device."),
            size_hint=(0.8, 0.3)
        ).open()

if __name__ == "__main__":
    PanelApp().run()
